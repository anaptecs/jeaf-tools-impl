Vista Pro basic  [vector]

Ammount of icons:
510

File Types:
.ai (v.10)

.png (bonus)
256x256 (32bit)

All icons are 100% vector and scalable 
Adobe Illustrator effects used in icons: drop shadow, blend, feather e.t.c